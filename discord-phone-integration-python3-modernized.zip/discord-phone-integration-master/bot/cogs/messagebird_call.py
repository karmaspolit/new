"""MessageBirdCall provider integration.

Provider SDK calls are run in a worker thread so they do not block Discord's event loop.
"""
import asyncio
import logging
from discord.ext import commands
from discord.ext.commands import BucketType
log = logging.getLogger(__name__)

class MessageBirdCallCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @commands.command(name="messagebird_call")
    @commands.dynamic_cooldown(lambda ctx: commands.Cooldown(1, int(ctx.bot.config["callCoolDown"])), BucketType.user)
    async def messagebird_call(self, ctx, *, message: str):
        cfg = self.bot.config
        allowed = {int(uid) for uid in cfg.get("authorizedUserIds", [])}
        if not allowed or ctx.author.id not in allowed:
            await ctx.send("This command is restricted. Ask the bot administrator to configure authorizedUserIds.")
            return
        limit = cfg["maxMsgLength"]
        if len(message) > limit:
            await ctx.send(f"{ctx.author.mention} Message exceeds the {limit}-character limit.")
            return
        required = ['messagebird_access_key', 'messagebird_from_number', 'messagebird_to_number']
        missing = [key for key in required if not cfg.get(key)]
        if missing:
            await ctx.send("messagebird_call is disabled; missing configuration: " + ", ".join(missing))
            return
        try:
            import messagebird
            cfg = self.bot.config
            client = messagebird.Client(cfg["messagebird_access_key"])
            response = await asyncio.to_thread(client.voice_create_call, source=cfg["messagebird_from_number"], destination=cfg["messagebird_to_number"], callflow={"title": "DiscordBotCall", "steps": [{"action": "say", "options": {"payload": message, "voice": cfg.get("messagebird_voice", "female"), "language": cfg.get("messagebird_language", "en-us")}}]})
            call_id = getattr(response, "id", "accepted")
            await ctx.send(f"Call request accepted by provider. Reference: {call_id} 📞")
        except Exception:
            log.exception("messagebird_call provider request failed")
            await ctx.send("The provider request failed. Check credentials, account permissions, API status, and bot logs.")

async def setup(bot):
    await bot.add_cog(MessageBirdCallCog(bot))
