"""PlivoCall provider integration.

Provider SDK calls are run in a worker thread so they do not block Discord's event loop.
"""
import asyncio
import logging
from discord.ext import commands
from discord.ext.commands import BucketType
log = logging.getLogger(__name__)

class PlivoCallCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @commands.command(name="plivo_call")
    @commands.dynamic_cooldown(lambda ctx: commands.Cooldown(1, int(ctx.bot.config["callCoolDown"])), BucketType.user)
    async def plivo_call(self, ctx, *, message: str):
        cfg = self.bot.config
        allowed = {int(uid) for uid in cfg.get("authorizedUserIds", [])}
        if not allowed or ctx.author.id not in allowed:
            await ctx.send("This command is restricted. Ask the bot administrator to configure authorizedUserIds.")
            return
        limit = cfg["maxMsgLength"]
        if len(message) > limit:
            await ctx.send(f"{ctx.author.mention} Message exceeds the {limit}-character limit.")
            return
        required = ['plivo_auth_id', 'plivo_auth_token', 'plivo_from_number', 'plivo_to_number']
        missing = [key for key in required if not cfg.get(key)]
        if missing:
            await ctx.send("plivo_call is disabled; missing configuration: " + ", ".join(missing))
            return
        try:
            from urllib.parse import urlencode
            import plivo
            client = plivo.RestClient(self.bot.config["plivo_auth_id"], self.bot.config["plivo_auth_token"])
            answer_url = "https://s3.amazonaws.com/plivocloud/PlivoTTS.xml?" + urlencode({"text": message})
            response = await asyncio.to_thread(client.calls.create, from_=self.bot.config["plivo_from_number"], to=self.bot.config["plivo_to_number"], answer_url=answer_url, answer_method="GET")
            call_id = getattr(response, "request_uuid", "accepted")
            await ctx.send(f"Call request accepted by provider. Reference: {call_id} 📞")
        except Exception:
            log.exception("plivo_call provider request failed")
            await ctx.send("The provider request failed. Check credentials, account permissions, API status, and bot logs.")

async def setup(bot):
    await bot.add_cog(PlivoCallCog(bot))
