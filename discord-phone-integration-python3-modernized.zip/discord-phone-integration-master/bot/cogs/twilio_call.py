"""TwilioCall provider integration.

Provider SDK calls are run in a worker thread so they do not block Discord's event loop.
"""
import asyncio
import logging
from discord.ext import commands
from discord.ext.commands import BucketType
log = logging.getLogger(__name__)

class TwilioCallCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @commands.command(name="twilio_call")
    @commands.dynamic_cooldown(lambda ctx: commands.Cooldown(1, int(ctx.bot.config["callCoolDown"])), BucketType.user)
    async def twilio_call(self, ctx, *, message: str):
        cfg = self.bot.config
        allowed = {int(uid) for uid in cfg.get("authorizedUserIds", [])}
        if not allowed or ctx.author.id not in allowed:
            await ctx.send("This command is restricted. Ask the bot administrator to configure authorizedUserIds.")
            return
        limit = cfg["maxMsgLength"]
        if len(message) > limit:
            await ctx.send(f"{ctx.author.mention} Message exceeds the {limit}-character limit.")
            return
        required = ['twilio_account_sid', 'twilio_auth_token', 'twilio_from_number', 'twilio_to_number']
        missing = [key for key in required if not cfg.get(key)]
        if missing:
            await ctx.send("twilio_call is disabled; missing configuration: " + ", ".join(missing))
            return
        try:
            from xml.sax.saxutils import escape
            from twilio.rest import Client
            client = Client(self.bot.config["twilio_account_sid"], self.bot.config["twilio_auth_token"])
            twiml = f"<Response><Say>{escape(message)}</Say></Response>"
            call = await asyncio.to_thread(client.calls.create, twiml=twiml, to=self.bot.config["twilio_to_number"], from_=self.bot.config["twilio_from_number"])
            call_id = call.sid
            await ctx.send(f"Call request accepted by provider. Reference: {call_id} 📞")
        except Exception:
            log.exception("twilio_call provider request failed")
            await ctx.send("The provider request failed. Check credentials, account permissions, API status, and bot logs.")

async def setup(bot):
    await bot.add_cog(TwilioCallCog(bot))
