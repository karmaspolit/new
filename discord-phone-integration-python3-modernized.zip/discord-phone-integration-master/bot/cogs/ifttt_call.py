"""IFTTT Webhooks integration."""
import logging
import aiohttp
from discord.ext import commands
from discord.ext.commands import BucketType
log = logging.getLogger(__name__)

class IFTTTCallCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @commands.command(name="call")
    @commands.dynamic_cooldown(lambda ctx: commands.Cooldown(1, int(ctx.bot.config["callCoolDown"])), BucketType.user)
    async def call(self, ctx, *, message: str):
        cfg = self.bot.config
        allowed = {int(uid) for uid in cfg.get("authorizedUserIds", [])}
        if not allowed or ctx.author.id not in allowed:
            await ctx.send("This command is restricted. Ask the bot administrator to configure authorizedUserIds.")
            return
        limit = cfg["maxMsgLength"]
        if len(message) > limit:
            await ctx.send(f"{ctx.author.mention} Message exceeds the {limit}-character limit.")
            return
        event, key = cfg.get("eventName"), cfg.get("IFTTTkey")
        if not event or not key:
            await ctx.send("IFTTT is disabled: configure eventName and IFTTTkey in config.json.")
            return
        url = f"https://maker.ifttt.com/trigger/{event}/with/key/{key}"
        payload = {"value1": f"New message. {message}", "value2": f"Sent by {ctx.author} in {ctx.guild.name if ctx.guild else 'DM'}."}
        try:
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(url, json=payload) as response:
                    if response.status < 200 or response.status >= 300:
                        log.warning("IFTTT returned HTTP %s", response.status)
                        await ctx.send(f"IFTTT rejected the request (HTTP {response.status}).")
                        return
            await ctx.send("IFTTT accepted the request; the configured applet may now place the call.")
        except (aiohttp.ClientError, TimeoutError):
            log.exception("IFTTT request failed")
            await ctx.send("Could not contact IFTTT. Check the bot logs and webhook settings.")

async def setup(bot):
    await bot.add_cog(IFTTTCallCog(bot))
