"""ClickSendCall provider integration.

Provider SDK calls are run in a worker thread so they do not block Discord's event loop.
"""
import asyncio
import logging
from discord.ext import commands
from discord.ext.commands import BucketType
log = logging.getLogger(__name__)

class ClickSendCallCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @commands.command(name="clicksend_call")
    @commands.dynamic_cooldown(lambda ctx: commands.Cooldown(1, int(ctx.bot.config["callCoolDown"])), BucketType.user)
    async def clicksend_call(self, ctx, *, message: str):
        cfg = self.bot.config
        allowed = {int(uid) for uid in cfg.get("authorizedUserIds", [])}
        if not allowed or ctx.author.id not in allowed:
            await ctx.send("This command is restricted. Ask the bot administrator to configure authorizedUserIds.")
            return
        limit = cfg["maxMsgLength"]
        if len(message) > limit:
            await ctx.send(f"{ctx.author.mention} Message exceeds the {limit}-character limit.")
            return
        required = ['clicksend_username', 'clicksend_api_key', 'clicksend_to_number']
        missing = [key for key in required if not cfg.get(key)]
        if missing:
            await ctx.send("clicksend_call is disabled; missing configuration: " + ", ".join(missing))
            return
        try:
            import clicksend_client
            from clicksend_client import VoiceApi, VoiceMessage
            cfg = self.bot.config
            configuration = clicksend_client.Configuration()
            configuration.username, configuration.password = cfg["clicksend_username"], cfg["clicksend_api_key"]
            api = VoiceApi(clicksend_client.ApiClient(configuration))
            request = VoiceMessage(to=cfg["clicksend_to_number"], body=message, voice=cfg.get("clicksend_voice", "female"), lang=cfg.get("clicksend_language", "en-us"))
            await asyncio.to_thread(api.voice_send_post, request)
            call_id = "accepted"
            await ctx.send(f"Call request accepted by provider. Reference: {call_id} 📞")
        except Exception:
            log.exception("clicksend_call provider request failed")
            await ctx.send("The provider request failed. Check credentials, account permissions, API status, and bot logs.")

async def setup(bot):
    await bot.add_cog(ClickSendCallCog(bot))
