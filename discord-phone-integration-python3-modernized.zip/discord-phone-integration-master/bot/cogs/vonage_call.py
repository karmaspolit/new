"""VonageCall provider integration.

Provider SDK calls are run in a worker thread so they do not block Discord's event loop.
"""
import asyncio
import logging
from discord.ext import commands
from discord.ext.commands import BucketType
log = logging.getLogger(__name__)

class VonageCallCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @commands.command(name="vonage_call")
    @commands.dynamic_cooldown(lambda ctx: commands.Cooldown(1, int(ctx.bot.config["callCoolDown"])), BucketType.user)
    async def vonage_call(self, ctx, *, message: str):
        cfg = self.bot.config
        allowed = {int(uid) for uid in cfg.get("authorizedUserIds", [])}
        if not allowed or ctx.author.id not in allowed:
            await ctx.send("This command is restricted. Ask the bot administrator to configure authorizedUserIds.")
            return
        limit = cfg["maxMsgLength"]
        if len(message) > limit:
            await ctx.send(f"{ctx.author.mention} Message exceeds the {limit}-character limit.")
            return
        required = ['vonage_api_key', 'vonage_api_secret', 'vonage_from_number', 'vonage_to_number']
        missing = [key for key in required if not cfg.get(key)]
        if missing:
            await ctx.send("vonage_call is disabled; missing configuration: " + ", ".join(missing))
            return
        try:
            import vonage
            client = vonage.Client(key=self.bot.config["vonage_api_key"], secret=self.bot.config["vonage_api_secret"])
            voice = vonage.Voice(client)
            ncco = [{"action": "talk", "voiceName": self.bot.config.get("vonage_voice", "Joanna"), "text": message}]
            response = await asyncio.to_thread(voice.create_call, {"to": [{"type": "phone", "number": self.bot.config["vonage_to_number"]}], "from": {"type": "phone", "number": self.bot.config["vonage_from_number"]}, "ncco": ncco})
            call_id = response.get("uuid", "accepted")
            await ctx.send(f"Call request accepted by provider. Reference: {call_id} 📞")
        except Exception:
            log.exception("vonage_call provider request failed")
            await ctx.send("The provider request failed. Check credentials, account permissions, API status, and bot logs.")

async def setup(bot):
    await bot.add_cog(VonageCallCog(bot))
