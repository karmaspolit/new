"""SinchCall provider integration.

Provider SDK calls are run in a worker thread so they do not block Discord's event loop.
"""
import asyncio
import logging
from discord.ext import commands
from discord.ext.commands import BucketType
log = logging.getLogger(__name__)

class SinchCallCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @commands.command(name="sinch_call")
    @commands.dynamic_cooldown(lambda ctx: commands.Cooldown(1, int(ctx.bot.config["callCoolDown"])), BucketType.user)
    async def sinch_call(self, ctx, *, message: str):
        cfg = self.bot.config
        allowed = {int(uid) for uid in cfg.get("authorizedUserIds", [])}
        if not allowed or ctx.author.id not in allowed:
            await ctx.send("This command is restricted. Ask the bot administrator to configure authorizedUserIds.")
            return
        limit = cfg["maxMsgLength"]
        if len(message) > limit:
            await ctx.send(f"{ctx.author.mention} Message exceeds the {limit}-character limit.")
            return
        required = ['sinch_key_id', 'sinch_key_secret', 'sinch_from_number', 'sinch_to_number']
        missing = [key for key in required if not cfg.get(key)]
        if missing:
            await ctx.send("sinch_call is disabled; missing configuration: " + ", ".join(missing))
            return
        try:
            from sinch import SinchClient
            cfg = self.bot.config
            client = SinchClient(key_id=cfg["sinch_key_id"], key_secret=cfg["sinch_key_secret"])
            response = await asyncio.to_thread(client.voice.callouts.tts, to=cfg["sinch_to_number"], from_=cfg["sinch_from_number"], text=message)
            call_id = response.get("callId", "accepted") if isinstance(response, dict) else getattr(response, "call_id", "accepted")
            await ctx.send(f"Call request accepted by provider. Reference: {call_id} 📞")
        except Exception:
            log.exception("sinch_call provider request failed")
            await ctx.send("The provider request failed. Check credentials, account permissions, API status, and bot logs.")

async def setup(bot):
    await bot.add_cog(SinchCallCog(bot))
