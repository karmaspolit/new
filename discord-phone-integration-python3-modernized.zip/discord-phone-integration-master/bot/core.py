"""Discord bot bootstrap compatible with discord.py 2.x."""
from __future__ import annotations
import logging
from pathlib import Path
import discord
from discord.ext import commands
from bot.config import load_config, ConfigError

log = logging.getLogger(__name__)

def setup_logging() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")

class PhoneBot(commands.Bot):
    async def setup_hook(self) -> None:
        cog_dir = Path(__file__).resolve().parent / "cogs"
        for path in sorted(cog_dir.glob("*_call.py")):
            extension = f"bot.cogs.{path.stem}"
            try:
                await self.load_extension(extension)
                log.info("Loaded extension %s", extension)
            except Exception:
                log.exception("Could not load extension %s", extension)

async def _on_ready(bot: commands.Bot) -> None:
    log.info("Discord bot connected as %s (ID %s)", bot.user, bot.user.id if bot.user else "unknown")

def create_bot() -> PhoneBot:
    try:
        config = load_config()
    except ConfigError as exc:
        raise SystemExit(f"Configuration error: {exc}") from exc
    intents = discord.Intents.default()
    intents.message_content = True  # Also enable Message Content Intent in the Discord Developer Portal.
    bot = PhoneBot(command_prefix=commands.when_mentioned_or(config["prefix"]), case_insensitive=True, intents=intents)
    bot.config = config

    @bot.event
    async def on_ready():
        await _on_ready(bot)

    @bot.event
    async def on_command_error(ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"⛔ Try again in {error.retry_after:.1f} seconds.")
        elif isinstance(error, commands.MissingRequiredArgument):
            await ctx.send("Please provide a message to read during the call.")
        elif isinstance(error, commands.CommandNotFound):
            return
        else:
            log.error("Command failed", exc_info=(type(error), error, error.__traceback__))
            await ctx.send("The command failed. Check the bot logs for details.")
    return bot

def run() -> None:
    setup_logging()
    bot = create_bot()
    bot.run(bot.config["discordToken"], log_handler=None)
