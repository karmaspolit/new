"""Configuration loading and validation."""
from __future__ import annotations
import json
import os
from pathlib import Path

class ConfigError(ValueError):
    """Raised when configuration is missing or invalid."""

def load_config(config_path: str | None = None) -> dict:
    path = Path(config_path) if config_path else Path(__file__).resolve().parent.parent / "config.json"
    try:
        with path.open("r", encoding="utf-8") as stream:
            config = json.load(stream)
    except FileNotFoundError as exc:
        raise ConfigError(f"Configuration file not found: {path}. Copy config.json.example to config.json.") from exc
    except json.JSONDecodeError as exc:
        raise ConfigError(f"Invalid JSON in {path} at line {exc.lineno}, column {exc.colno}.") from exc
    if not isinstance(config, dict):
        raise ConfigError("Configuration root must be a JSON object.")
    for key in ("discordToken", "prefix"):
        if not isinstance(config.get(key), str) or not config[key].strip():
            raise ConfigError(f"Missing or empty required setting: {key}")
    try:
        config["callCoolDown"] = int(config.get("callCoolDown", 30))
        config["maxMsgLength"] = int(config.get("maxMsgLength", 250))
    except (TypeError, ValueError) as exc:
        raise ConfigError("callCoolDown and maxMsgLength must be integers.") from exc
    if config["callCoolDown"] < 1:
        raise ConfigError("callCoolDown must be at least 1 second.")
    if not 1 <= config["maxMsgLength"] <= 1900:
        raise ConfigError("maxMsgLength must be between 1 and 1900 characters.")
    return config
