# Discord Phone Call Bot (modernized)

A modular Discord bot that requests text-to-speech phone calls through configured provider APIs. Phone calls may incur charges. Restrict bot access to trusted users and only call numbers you own or have permission to contact.

## Requirements

- Python 3.11 or 3.12 recommended
- A Discord bot token with **Message Content Intent** enabled in the Discord Developer Portal
- Credentials, an enabled voice product, and a verified caller ID/number for the provider you use

## Install

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Copy `config.json.example` to `config.json`, then edit it. `config.json` is intentionally not included in source control. Set `discordToken` and `prefix`; set `authorizedUserIds` to a list of Discord numeric user IDs allowed to trigger calls (empty means nobody is authorized), and set only the credentials for the provider(s) you intend to use. IFTTT requires both `eventName` and `IFTTTkey`; those are optional if using another provider. Keep secrets private and rotate them immediately if exposed.

Run with `python main.py`. Commands are `!call` (IFTTT), `!twilio_call`, `!vonage_call`, `!plivo_call`, `!clicksend_call`, `!messagebird_call`, and `!sinch_call` by default, depending on configuration and provider account/API support. Each command has a per-user cooldown and a configurable message-length limit.

## Important compatibility notes

- Updated to discord.py 2.x asynchronous extension setup.
- Removed the obsolete third-party `asyncio` dependency; `asyncio` is part of Python.
- Blocking provider SDK calls run in a worker thread to reduce Discord event-loop stalls.
- IFTTT HTTP responses and timeouts are checked; provider errors are logged without echoing potentially sensitive API response details into Discord.
- Twilio speech text is XML-escaped and Plivo's hosted TTS query is URL-encoded.
- The provider SDKs are still provider-specific. A command being loadable does **not** prove that an account has Voice API access or that the provider SDK's current API accepts the request. Verify each provider with its sandbox/test account and current provider documentation before production use. In particular, hosted Plivo TTS and legacy MessageBird/Sinch/ClickSend API behavior may depend on account and API-version availability.

## Security

Do not allow arbitrary members to trigger paid calls. Use Discord channel/role permissions or add an explicit allow-list before enabling this bot in a shared server. Use provider spending limits, monitor call logs, and do not commit `config.json`.
